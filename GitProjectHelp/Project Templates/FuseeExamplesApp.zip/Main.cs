﻿using Fusee.Engine;

namespace Examples.$safeprojectname$
{
    public class $safeprojectname$ : RenderCanvas 
    {
        public override void Init()
        {
            // is called on startup
        }

        public override void RenderAFrame()
        {
            // is called once a frame
        }

        public override void Resize()
        {
            // is called when window got resized
        }

        public static void Main()
        {
            var app = new $safeprojectname$();
            app.Run();
        }

    }
}
